# 0.1.1.0

Add solving with assumptions: `solveAssuming_` and `solveAssuming`.
These don't make solver state unsat.

# 0.1.0.0

Initial release
